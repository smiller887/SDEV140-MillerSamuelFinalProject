# Importing the libraries we need
# EasyFrame helps us create a simple GUI (Graphical User Interface) window.
from breezypythongui import EasyFrame  
# messagebox helps us show pop-up messages to the user (like errors or confirmations).
from tkinter import messagebox  
# PhotoImage is used to display images in our GUI.
from tkinter import PhotoImage  

# MainMenu class - this is the first screen the user sees when they open the app
class MainMenu(EasyFrame):
    def __init__(self):
        # Setting up the main menu window with a title and size
        EasyFrame.__init__(self, title="Coffee Craze", width=500, height=400)

        # Adding a welcome message to the top of the window
        self.addLabel(text="      Welcome to Coffee Craze!", row=0, column=1, columnspan=2, font=("Arial", 24))

        # Adding an image under the welcome message
        imageLabel_1 = self.addLabel(text="", row=1, column=1, sticky="NSEW")  
        self.image_1 = PhotoImage(file="C:/Python/coffee_ad.png")  # Load the image from the given path
        imageLabel_1["image"] = self.image_1  # Display the image on the label

        # Adding a button that says "Start Order". When clicked, it opens the next page to order coffee
        self.addButton(text="Start Order", row=2, column=1, columnspan=2, command=self.startOrder)

    # This function gets called when the user clicks "Start Order"
    def startOrder(self):
        self.destroy()  # Close the current main menu window
        CoffeeApp().mainloop()  # Open the CoffeeApp window where the user can make their order

# CoffeeApp class - the page where the user selects their coffee, size, sugar, and milk
class CoffeeApp(EasyFrame):
    def __init__(self):
        # Setting up the coffee ordering page with a title and size
        EasyFrame.__init__(self, title="Coffee Ordering", width=550, height=400)  

        # Creating variables to store the user's selections
        self.selected_coffee = ""  # What type of coffee the user selected (e.g., Espresso, Latte)
        self.size = ""  # The size of the coffee (Small, Medium, Large)
        self.sugar = 0  # Number of sugars the user wants (0, 1, or 2)
        self.milk = 0  # The type of milk the user wants (No Milk, Regular Milk, Soy Milk)

        # Adding images for each type of coffee
        imageLabel_2 = self.addLabel(text="", row=1, column=0, sticky="NSEW")  
        self.image_2 = PhotoImage(file="C:/Python/espresso.png")  # Load the Espresso image
        imageLabel_2["image"] = self.image_2  # Display the Espresso image

        imageLabel_3 = self.addLabel(text="", row=1, column=1, sticky="NSEW")  
        self.image_3 = PhotoImage(file="C:/Python/latte.png")  # Load the Latte image
        imageLabel_3["image"] = self.image_3  # Display the Latte image

        imageLabel_4 = self.addLabel(text="", row=1, column=2, sticky="NSEW")  
        self.image_4 = PhotoImage(file="C:/Python/iced_coffee.png")  # Load the Iced Coffee image
        imageLabel_4["image"] = self.image_4  # Display the Iced Coffee image

        # Adding buttons to let the user choose the type of coffee they want
        self.addButton(text="Espresso", row=2, column=0, command=self.selectEspresso)  # Button for Espresso
        self.addButton(text="Latte", row=2, column=1, command=self.selectLatte)  # Button for Latte
        self.addButton(text="Iced Coffee", row=2, column=2, command=self.selectIcedCoffee)  # Button for Iced Coffee

        # Adding buttons for choosing the size of the coffee
        self.addLabel(text="Choose Size:", row=3, column=0)  # Label above size buttons
        self.addButton(text="Small", row=3, column=1, command=self.selectSmall)  # Button for Small size
        self.addButton(text="Medium", row=3, column=2, command=self.selectMedium)  # Button for Medium size
        self.addButton(text="Large", row=3, column=3, command=self.selectLarge)  # Button for Large size

        # Adding buttons for choosing how much sugar to add
        self.addLabel(text="Sugar:", row=4, column=0)  # Label above sugar buttons
        self.addButton(text="No Sugar", row=4, column=1, command=self.noSugar)  # Button for No Sugar
        self.addButton(text="1 Sugar", row=4, column=2, command=self.oneSugar)  # Button for 1 Sugar
        self.addButton(text="2 Sugars", row=4, column=3, command=self.twoSugars)  # Button for 2 Sugars

        # Adding buttons for choosing the type of milk
        self.addLabel(text="Milk:", row=5, column=0)  # Label above milk buttons
        self.addButton(text="No Milk", row=5, column=1, command=self.noMilk)  # Button for No Milk
        self.addButton(text="Regular Milk", row=5, column=2, command=self.regularMilk)  # Button for Regular Milk
        self.addButton(text="Soy Milk", row=5, column=3, command=self.soyMilk)  # Button for Soy Milk

        # Adding the final "Order" button and a "Back to Main Menu" button
        self.addButton(text="Order", row=6, column=1, columnspan=2, command=self.placeOrder)  # Button to confirm order
        self.addButton(text="Back to Main Menu", row=8, column=1, columnspan=2, command=self.backToMainMenu)  # Button to go back

    # Functions for selecting coffee types
    def selectEspresso(self):
        self.selected_coffee = "Espresso"  # Set the coffee to Espresso
        self.displaySelection()  # Show the current selection to the user

    def selectLatte(self):
        self.selected_coffee = "Latte"  # Set the coffee to Latte
        self.displaySelection()  # Show the current selection to the user

    def selectIcedCoffee(self):
        self.selected_coffee = "Iced Coffee"  # Set the coffee to Iced Coffee
        self.displaySelection()  # Show the current selection to the user

    # Functions for selecting the size of the coffee
    def selectSmall(self):
        self.size = "Small"  # Set the size to Small
        self.displaySelection()  # Show the current selection to the user

    def selectMedium(self):
        self.size = "Medium"  # Set the size to Medium
        self.displaySelection()  # Show the current selection to the user

    def selectLarge(self):
        self.size = "Large"  # Set the size to Large
        self.displaySelection()  # Show the current selection to the user

    # Functions for selecting sugar amount
    def noSugar(self):
        self.sugar = 0  # Set sugar to 0 (No Sugar)
        self.displaySelection()  # Show the current selection to the user

    def oneSugar(self):
        self.sugar = 1  # Set sugar to 1
        self.displaySelection()  # Show the current selection to the user

    def twoSugars(self):
        self.sugar = 2  # Set sugar to 2
        self.displaySelection()  # Show the current selection to the user

    # Functions for selecting milk type
    def noMilk(self):
        self.milk = "No Milk"  # Set milk to No Milk
        self.displaySelection()  # Show the current selection to the user

    def regularMilk(self):
        self.milk = "Regular Milk"  # Set milk to Regular Milk
        self.displaySelection()  # Show the current selection to the user

    def soyMilk(self):
        self.milk = "Soy Milk"  # Set milk to Soy Milk
        self.displaySelection()  # Show the current selection to the user

    # Function to display the user's current coffee selection
    def displaySelection(self):
        # Create a string that shows the coffee type, size, sugar, and milk
        selection = f"Coffee: {self.selected_coffee}, Size: {self.size}, Sugar: {self.sugar}, Milk: {self.milk}"
        # Display that string in the window so the user can see their choices
        self.addLabel(text=selection, row=7, column=0, columnspan=4)

    # Function to place the order and confirm the user's choices
    def placeOrder(self):
        # If no coffee type or size is selected, show a warning message
        if not self.selected_coffee or not self.size:
            messagebox.showwarning("Invalid Input", "Please select a coffee type and size.")  # Show warning
            return  # Exit the function if input is invalid

        # Create a message showing the user's order details
        order_details = f"Your order: {self.selected_coffee}, Size: {self.size}, Sugar: {self.sugar}, Milk: {self.milk}"
        messagebox.showinfo("Order Confirmed", order_details)  # Show the order details in a pop-up message

    # Function to go back to the main menu screen
    def backToMainMenu(self):
        self.destroy()  # Close the current ordering page
        MainMenu().mainloop()  # Open the main menu screen again

# Run the program by opening the main menu first
MainMenu().mainloop()  # Start the application with the main menu
